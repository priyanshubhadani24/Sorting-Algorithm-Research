import random

random_numbers = [random.randint(1, 10000) for _ in range(10)]

with open("test.txt", "w") as file:
    for number in random_numbers:
        file.write(f"{number}\n")

print("Random numbers have been written to 'test.txt'.")
